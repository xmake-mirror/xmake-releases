template("qt.quickapp")
    add_configfiles("xmake.lua")

