template("qt.quickapp_static")
    add_configfiles("xmake.lua")

