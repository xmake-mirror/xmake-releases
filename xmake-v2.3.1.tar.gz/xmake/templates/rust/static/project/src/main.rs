extern crate interfaces;

fn main() 
{
    println!("hello xmake!");
    println!("add: {}", interfaces::add(1, 1));
}
