#ifndef QT_DEMO_H
#define QT_DEMO_H

#include "demo_global.h"

class QT_DEMOSHARED_EXPORT QtDemo
{

public:
    QtDemo();
};

#endif // QT_TEST5_H
