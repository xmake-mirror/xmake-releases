#include "demo.h"

QtDemo::QtDemo()
{
}
