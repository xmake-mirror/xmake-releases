#include <semver.h>

int main()
{
    semvern(0, 0, 0);
    return 0;
}
