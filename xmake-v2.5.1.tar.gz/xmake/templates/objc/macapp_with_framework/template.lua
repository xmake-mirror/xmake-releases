template("xcode.macapp_with_framework")
    add_configfiles("xmake.lua")
