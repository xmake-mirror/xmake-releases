template("qt.static")
    add_configfiles("xmake.lua")

