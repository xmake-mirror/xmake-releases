#import <Foundation/Foundation.h>

int main(int argc, char** argv)
{
    @autoreleasepool
    {
        NSLog(@"hello world!");
    }
    return 0;
}
