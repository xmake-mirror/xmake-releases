template("xcode.framework")
    add_configfiles("xmake.lua")
