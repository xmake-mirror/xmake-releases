template("static")
    add_configfiles("xmake.lua")
