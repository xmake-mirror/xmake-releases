int luaopen_cjson(void *l);

int main()
{
    luaopen_cjson(0);
    return 0;
}
