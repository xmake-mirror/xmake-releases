template("qt.widgetapp")
    add_configfiles("xmake.lua")

