#include <luajit.h>

int main()
{
    lua_pcall(0, 0, 0, 0);
    return 0;
}
