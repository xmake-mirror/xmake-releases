#include <stdio.h>
#include <readline/readline.h>

int main()
{
    readline(0);
    return 0;
}
