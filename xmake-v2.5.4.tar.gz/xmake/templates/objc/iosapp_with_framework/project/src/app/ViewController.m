//
//  ViewController.m
//  test5
//
//  Created by ruki on 2020/4/8.
//  Copyright © 2020 tboox. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
