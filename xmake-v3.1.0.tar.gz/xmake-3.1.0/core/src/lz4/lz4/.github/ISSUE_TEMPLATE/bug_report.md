---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**Expected behavior**
Please describe what you expected to happen.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error '...'
If applicable, add screenshots to help explain your problem.

**System (please complete the following information):**
 - OS: [e.g. Mac]
 - Version [e.g. 22]
 - Compiler [e.g. gcc]
 - Build System [e.g. Makefile]
 - Other hardware specs [e.g. Core 2 duo...]

**Additional context**
Add any other context about the problem here.
